//
//  HelloIndia.h
//  HelloCountry
//
//  Created by Droid on 29/06/22.
//

#import <Foundation/Foundation.h>
//#import <HelloWorld.framework/Headers/HelloWorld.h>
#import <HelloWorld/HelloWorld.h>

@interface HelloIndia : NSObject
//@property HelloWorld
- (NSString *) helloCountry: (NSString *) name;

@end
