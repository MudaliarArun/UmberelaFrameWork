//
//  HelloWorld.h
//  HelloWorld
//
//  Created by MacbookPro-Briskstar on 29/06/22.
//

#import <Foundation/Foundation.h>

//! Project version number for HelloWorld.
FOUNDATION_EXPORT double HelloWorldVersionNumber;

//! Project version string for HelloWorld.
FOUNDATION_EXPORT const unsigned char HelloWorldVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloWorld/PublicHeader.h>
#import <HelloWorld/HelloBuddy.h>

