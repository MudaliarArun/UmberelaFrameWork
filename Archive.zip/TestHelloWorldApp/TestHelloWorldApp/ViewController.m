//
//  ViewController.m
//  TestHelloWorldApp
//
//  Created by MacbookPro-Briskstar on 29/06/22.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
