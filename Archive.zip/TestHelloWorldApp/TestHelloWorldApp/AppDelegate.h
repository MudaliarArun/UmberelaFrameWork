//
//  AppDelegate.h
//  TestHelloWorldApp
//
//  Created by MacbookPro-Briskstar on 29/06/22.
//

#import <UIKit/UIKit.h>
//#import "HelloCountry.framework/Frameworks/HelloWorld.framework/Headers/HelloWorld.h"
//#import "HelloCountry/HelloCountry.h"
#import "HelloCountry/HelloCountry.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

