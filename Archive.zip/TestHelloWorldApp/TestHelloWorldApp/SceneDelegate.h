//
//  SceneDelegate.h
//  TestHelloWorldApp
//
//  Created by MacbookPro-Briskstar on 29/06/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

